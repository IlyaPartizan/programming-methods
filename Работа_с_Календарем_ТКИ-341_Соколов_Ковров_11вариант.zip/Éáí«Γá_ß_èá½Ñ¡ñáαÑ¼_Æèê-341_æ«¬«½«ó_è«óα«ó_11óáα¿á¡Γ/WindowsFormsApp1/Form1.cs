﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.monthCalendar1.DateSelected += new System.Windows.Forms.DateRangeEventHandler(this.monthCalendar1_DateSelected);
            File.WriteAllText(@"calendar.txt", string.Empty);
            UpdateBoldedDates();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            help newForm = new help();
            newForm.Show();
        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            UpdateBoldedDates();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }
        private void button3_Click(object sender, EventArgs e)
        {
            Form1.ActiveForm.Close();
        }
        private void button4_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
        }

        private void monthCalendar1_DateSelected(object sender, DateRangeEventArgs e)
        {
            DateTime selectedDate = e.Start;
            string filePath = @"calendar.txt";
            using (StreamWriter writer = new StreamWriter(filePath, true))
            {
                writer.WriteLine(selectedDate.ToString("yyyy-MM-dd"));
            }
            monthCalendar1.AddBoldedDate(selectedDate);
            monthCalendar1.UpdateBoldedDates();
        }
        private void UpdateBoldedDates()
        {
            if (int.TryParse(textBox1.Text, out int N))
            {
                monthCalendar2.RemoveAllBoldedDates();
                string[] dates = File.ReadAllLines(@"calendar.txt");
                foreach (string dateString in dates)
                {
                    if (DateTime.TryParse(dateString, out DateTime date))
                    {
                        DateTime newDate = date.AddDays(N);
                        monthCalendar2.AddBoldedDate(newDate);
                    }
                }
                monthCalendar2.UpdateBoldedDates();
                File.WriteAllLines(@"calendar2.txt", monthCalendar2.BoldedDates.Select(d => d.ToString("yyyy-MM-dd")));
            }
        }

        private void button5_Click_1(object sender, EventArgs e)
        {
            File.WriteAllText(@"calendar.txt", string.Empty);
            File.WriteAllText(@"calendar2.txt", string.Empty);
            monthCalendar1.RemoveAllBoldedDates();
            monthCalendar2.RemoveAllBoldedDates();
            monthCalendar1.UpdateBoldedDates();
            monthCalendar2.UpdateBoldedDates();
            textBox1.Text = "";
        }
    }
}
