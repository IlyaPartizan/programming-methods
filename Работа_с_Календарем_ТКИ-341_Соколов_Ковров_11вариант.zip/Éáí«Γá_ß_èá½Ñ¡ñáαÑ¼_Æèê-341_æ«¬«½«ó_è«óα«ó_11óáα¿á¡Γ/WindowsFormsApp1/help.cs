﻿using System;
using System.IO;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class help : Form
    {
        int count = 0;
        public help()
        {
            InitializeComponent();
            richTextBox1.Text = ReadHelpText(@"first_list_help.txt");
            textBox1.Text = "Лист 1. Кнопки";
        }
        
        private void button1_Click(object sender, EventArgs e)
        {
            count = (count - 1) % 3;
            if (count < 0)
            {
                count = 2;
            }
                if (count == 0)
            {
                richTextBox1.Text = ReadHelpText(@"first_list_help.txt");
                textBox1.Text = "Лист 1. Кнопки";
            }
            else if (count == 1)
            {
                richTextBox1.Text = ReadHelpText(@"second_list_help.txt");
                textBox1.Text = "Лист 2. Календари и поле ввода";
            }
            else
            {
                richTextBox1.Text = ReadHelpText(@"third_list_help.txt");
                textBox1.Text = "Лист 3. Справочная информация";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            count = (count + 1) % 3;
            if (count == 0)
            {
                richTextBox1.Text = ReadHelpText(@"first_list_help.txt");
                textBox1.Text = "Лист 1. Кнопки";
            }
            else if (count == 1)
            {
                richTextBox1.Text = ReadHelpText(@"second_list_help.txt");
                textBox1.Text = "Лист 2. Календари и поле ввода";
            }
            else
            {
                richTextBox1.Text = ReadHelpText(@"third_list_help.txt");
                textBox1.Text = "Лист 3. Справочная информация";
            }

        }

        string ReadHelpText(string filePath)
        {
            try
            {
                using (StreamReader sr = new StreamReader(filePath))
                {
                    return sr.ReadToEnd();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при чтении файла: " + ex.Message);
                return string.Empty;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            help.ActiveForm.Close();
        }
    }
}
